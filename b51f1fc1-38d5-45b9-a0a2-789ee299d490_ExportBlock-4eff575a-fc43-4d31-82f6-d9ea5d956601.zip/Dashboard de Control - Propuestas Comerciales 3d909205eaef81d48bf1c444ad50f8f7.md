# Dashboard de Control - Propuestas Comerciales

# Dashboard en vivo

> Todos los números y vistas de esta página se recalculan solos con cada consulta — no son una foto fija. Si acabás de correr el flujo, refrescá la página de Notion para ver los datos actualizados.
> 

Los gráficos y tablas de abajo muestran, en este orden: cantidad de propuestas por Estado, total de errores registrados, el tablero completo de Propuestas, y el detalle del Log de Errores.

[Sin título](Sin%20t%C3%ADtulo%203d909205eaef81a2bbcbca41724b58fa.csv)

[Sin título](Sin%20t%C3%ADtulo%203d909205eaef8104a462eef9703a6c23.csv)

[Sin título](Sin%20t%C3%ADtulo%203d909205eaef815cb2b0cb192b400a2a.csv)

[Sin título](Sin%20t%C3%ADtulo%203d909205eaef8192a399cf89f56e0685.csv)